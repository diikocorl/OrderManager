//>>built
define("dijit/nls/pt/common",({buttonOk:"OK",buttonCancel:"Cancelar",buttonSave:"Salvar",itemClose:"Fechar"}));
