//>>built
define("dijit/nls/kk/loading",({loadingState:"Қотарылуда...",errorState:"Кешіріңіз, қате орын алды"}));
