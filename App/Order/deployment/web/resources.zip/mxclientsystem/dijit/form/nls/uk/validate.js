//>>built
define("dijit/form/nls/uk/validate",({invalidMessage:"Введено невірне значення.",missingMessage:"Це значення є обов'язковим.",rangeMessage:"Це значення за межами діапазону."}));
